"""
╔══════════════════════════════════════════════════════════╗
║         TELEGRAM SHOP BOT - LANGUAGE SYSTEM              ║
║        Arabic / English / French Support                 ║
╚══════════════════════════════════════════════════════════╝
"""

from typing import Dict, Any

# ─────────────────────────────────────────────
#  LANGUAGE STRINGS
# ─────────────────────────────────────────────

STRINGS: Dict[str, Dict[str, str]] = {

    # ── GENERAL ──────────────────────────────
    "btn_back":         {"en": "◀️ Back",         "ar": "◀️ رجوع",        "fr": "◀️ Retour"},
    "btn_home":         {"en": "🏠 Home",          "ar": "🏠 الرئيسية",    "fr": "🏠 Accueil"},
    "btn_cancel":       {"en": "✖️ Cancel",        "ar": "✖️ إلغاء",       "fr": "✖️ Annuler"},
    "btn_confirm":      {"en": "✅ Confirm",       "ar": "✅ تأكيد",        "fr": "✅ Confirmer"},
    "btn_refresh":      {"en": "🔄 Refresh",       "ar": "🔄 تحديث",       "fr": "🔄 Actualiser"},
    "btn_next":         {"en": "▶️ Next",          "ar": "▶️ التالي",      "fr": "▶️ Suivant"},
    "btn_prev":         {"en": "◀️ Prev",          "ar": "◀️ السابق",      "fr": "◀️ Précédent"},

    # ── MAIN MENU ─────────────────────────────
    "main_menu_title":  {
        "en": "🏠 <b>Main Menu</b>",
        "ar": "🏠 <b>القائمة الرئيسية</b>",
        "fr": "🏠 <b>Menu Principal</b>"
    },
    "btn_shop":         {"en": "🛒 Shop",          "ar": "🛒 المتجر",       "fr": "🛒 Boutique"},
    "btn_my_balance":   {"en": "💰 My Balance",    "ar": "💰 رصيدي",        "fr": "💰 Mon Solde"},
    "btn_my_orders":    {"en": "📜 My Orders",     "ar": "📜 طلباتي",       "fr": "📜 Mes Commandes"},
    "btn_my_profile":   {"en": "👤 My Profile",    "ar": "👤 ملفي",         "fr": "👤 Mon Profil"},
    "btn_search":       {"en": "🔍 Search",        "ar": "🔍 بحث",          "fr": "🔍 Recherche"},
    "btn_referral":     {"en": "🔗 Referral",      "ar": "🔗 الإحالة",      "fr": "🔗 Parrainage"},
    "btn_support":      {"en": "💬 Support",       "ar": "💬 الدعم",        "fr": "💬 Support"},
    "btn_language":     {"en": "🌐 Language",      "ar": "🌐 اللغة",        "fr": "🌐 Langue"},

    # ── SHOP / PRODUCTS ───────────────────────
    "shop_title":       {
        "en": "🛒 <b>Shop</b>\nBrowse our premium digital products",
        "ar": "🛒 <b>المتجر</b>\nتصفح منتجاتنا الرقمية المميزة",
        "fr": "🛒 <b>Boutique</b>\nParcourez nos produits numériques premium"
    },
    "select_category":  {
        "en": "📂 <b>Select a category</b> to browse products:",
        "ar": "📂 <b>اختر فئة</b> لتصفح المنتجات:",
        "fr": "📂 <b>Sélectionnez une catégorie</b> pour parcourir les produits:"
    },
    "no_categories":    {
        "en": "📭 No categories available yet.",
        "ar": "📭 لا توجد فئات متاحة حتى الآن.",
        "fr": "📭 Aucune catégorie disponible pour l'instant."
    },
    "no_products":      {
        "en": "📭 No products in this category yet.",
        "ar": "📭 لا توجد منتجات في هذه الفئة حتى الآن.",
        "fr": "📭 Aucun produit dans cette catégorie pour l'instant."
    },
    "product_detail":   {
        "en": (
            "📦 <b>{name}</b>\n\n"
            "{description}\n\n"
            "💰 Price: <b>${price}</b>\n"
            "⭐ Stars: <b>{price_stars}</b>\n"
            "📦 Stock: <b>{stock}</b>\n"
            "🔥 Sold: <b>{total_sold}</b>"
        ),
        "ar": (
            "📦 <b>{name}</b>\n\n"
            "{description}\n\n"
            "💰 السعر: <b>${price}</b>\n"
            "⭐ النجوم: <b>{price_stars}</b>\n"
            "📦 المخزون: <b>{stock}</b>\n"
            "🔥 مباع: <b>{total_sold}</b>"
        ),
        "fr": (
            "📦 <b>{name}</b>\n\n"
            "{description}\n\n"
            "💰 Prix: <b>${price}</b>\n"
            "⭐ Étoiles: <b>{price_stars}</b>\n"
            "📦 Stock: <b>{stock}</b>\n"
            "🔥 Vendu: <b>{total_sold}</b>"
        ),
    },
    "stock_unlimited":  {"en": "Unlimited", "ar": "غير محدود", "fr": "Illimité"},
    "out_of_stock":     {"en": "❌ Out of Stock", "ar": "❌ نفذ المخزون", "fr": "❌ Rupture de stock"},
    "btn_buy_usd":      {"en": "💵 Buy with Balance", "ar": "💵 شراء بالرصيد", "fr": "💵 Acheter avec le solde"},
    "btn_buy_stars":    {"en": "⭐ Buy with Stars", "ar": "⭐ شراء بالنجوم", "fr": "⭐ Acheter avec des étoiles"},

    # ── BALANCE / WALLET ──────────────────────
    "balance_title":    {
        "en": (
            "💰 <b>My Wallet</b>\n\n"
            "💵 Balance: <b>${balance}</b>\n"
            "⭐ Stars: <b>{stars}</b>\n"
            "📊 Total Spent: <b>${spent}</b>\n"
            "📦 Total Orders: <b>{orders}</b>"
        ),
        "ar": (
            "💰 <b>محفظتي</b>\n\n"
            "💵 الرصيد: <b>${balance}</b>\n"
            "⭐ النجوم: <b>{stars}</b>\n"
            "📊 إجمالي الإنفاق: <b>${spent}</b>\n"
            "📦 إجمالي الطلبات: <b>{orders}</b>"
        ),
        "fr": (
            "💰 <b>Mon Portefeuille</b>\n\n"
            "💵 Solde: <b>${balance}</b>\n"
            "⭐ Étoiles: <b>{stars}</b>\n"
            "📊 Total Dépensé: <b>${spent}</b>\n"
            "📦 Total Commandes: <b>{orders}</b>"
        ),
    },
    "btn_deposit_usdt": {"en": "💎 Deposit USDT", "ar": "💎 إيداع USDT", "fr": "💎 Dépôt USDT"},
    "btn_deposit_stars":{"en": "⭐ Buy Stars", "ar": "⭐ شراء نجوم", "fr": "⭐ Acheter des étoiles"},
    "deposit_usdt_info":{
        "en": (
            "💎 <b>USDT Deposit</b> (TRC20)\n\n"
            "📋 <b>Wallet Address:</b>\n<code>{wallet}</code>\n\n"
            "📌 <b>Minimum:</b> ${min_deposit}\n"
            "⚡ After sending, tap below and enter your TX hash.\n\n"
            "⚠️ Only send USDT on TRC20 network!"
        ),
        "ar": (
            "💎 <b>إيداع USDT</b> (TRC20)\n\n"
            "📋 <b>عنوان المحفظة:</b>\n<code>{wallet}</code>\n\n"
            "📌 <b>الحد الأدنى:</b> ${min_deposit}\n"
            "⚡ بعد الإرسال، اضغط أدناه وأدخل هاش المعاملة.\n\n"
            "⚠️ أرسل USDT على شبكة TRC20 فقط!"
        ),
        "fr": (
            "💎 <b>Dépôt USDT</b> (TRC20)\n\n"
            "📋 <b>Adresse du portefeuille:</b>\n<code>{wallet}</code>\n\n"
            "📌 <b>Minimum:</b> ${min_deposit}\n"
            "⚡ Après l'envoi, appuyez ci-dessous et entrez votre hash TX.\n\n"
            "⚠️ Envoyez uniquement USDT sur le réseau TRC20!"
        ),
    },
    "btn_submit_tx":    {"en": "📤 Submit TX Hash", "ar": "📤 إرسال هاش المعاملة", "fr": "📤 Soumettre hash TX"},
    "ask_amount":       {"en": "💵 Enter deposit amount (USD):", "ar": "💵 أدخل مبلغ الإيداع (دولار):", "fr": "💵 Entrez le montant du dépôt (USD):"},
    "ask_tx_hash":      {"en": "📋 Enter your TRC20 transaction hash:", "ar": "📋 أدخل هاش معاملتك TRC20:", "fr": "📋 Entrez votre hash de transaction TRC20:"},
    "deposit_submitted":{
        "en": "✅ <b>Deposit submitted!</b>\nWe'll verify and credit your account shortly.\n\nDeposit ID: <code>{dep_id}</code>",
        "ar": "✅ <b>تم تقديم الإيداع!</b>\nسنتحقق ونضيف الرصيد لحسابك قريبًا.\n\nرقم الإيداع: <code>{dep_id}</code>",
        "fr": "✅ <b>Dépôt soumis!</b>\nNous vérifierons et créditerons votre compte sous peu.\n\nID de dépôt: <code>{dep_id}</code>",
    },

    # ── PURCHASE FLOW ─────────────────────────
    "insufficient_balance": {
        "en": "❌ <b>Insufficient balance!</b>\nYou need <b>${needed}</b> but have <b>${have}</b>.",
        "ar": "❌ <b>رصيد غير كافٍ!</b>\nتحتاج <b>${needed}</b> لكن لديك <b>${have}</b>.",
        "fr": "❌ <b>Solde insuffisant!</b>\nVous avez besoin de <b>${needed}</b> mais vous avez <b>${have}</b>.",
    },
    "purchase_confirm": {
        "en": "🛒 <b>Confirm Purchase</b>\n\n📦 Product: <b>{name}</b>\n💰 Price: <b>${price}</b>\n\n🎟️ Coupon: <b>{coupon}</b>\n💵 Final Price: <b>${final}</b>",
        "ar": "🛒 <b>تأكيد الشراء</b>\n\n📦 المنتج: <b>{name}</b>\n💰 السعر: <b>${price}</b>\n\n🎟️ القسيمة: <b>{coupon}</b>\n💵 السعر النهائي: <b>${final}</b>",
        "fr": "🛒 <b>Confirmer l'achat</b>\n\n📦 Produit: <b>{name}</b>\n💰 Prix: <b>${price}</b>\n\n🎟️ Coupon: <b>{coupon}</b>\n💵 Prix final: <b>${final}</b>",
    },
    "btn_apply_coupon":  {"en": "🎟️ Apply Coupon", "ar": "🎟️ تطبيق قسيمة", "fr": "🎟️ Appliquer Coupon"},
    "ask_coupon_code":   {"en": "🎟️ Enter coupon code:", "ar": "🎟️ أدخل كود القسيمة:", "fr": "🎟️ Entrez le code coupon:"},
    "coupon_valid":      {"en": "✅ Coupon applied! Saving <b>${discount}</b>", "ar": "✅ تم تطبيق القسيمة! توفير <b>${discount}</b>", "fr": "✅ Coupon appliqué! Économie de <b>${discount}</b>"},
    "coupon_invalid":    {"en": "❌ Invalid or expired coupon code.", "ar": "❌ كود القسيمة غير صالح أو منتهي الصلاحية.", "fr": "❌ Code coupon invalide ou expiré."},
    "purchase_success":  {
        "en": "✅ <b>Purchase Successful!</b>\n\n🚀 Your product is being delivered below 👇\n\nOrder ID: <code>{order_id}</code>",
        "ar": "✅ <b>تمت عملية الشراء بنجاح!</b>\n\n🚀 منتجك يتم تسليمه أدناه 👇\n\nرقم الطلب: <code>{order_id}</code>",
        "fr": "✅ <b>Achat réussi!</b>\n\n🚀 Votre produit est livré ci-dessous 👇\n\nID de commande: <code>{order_id}</code>",
    },

    # ── ORDERS ────────────────────────────────
    "orders_title":     {
        "en": "📜 <b>My Order History</b>",
        "ar": "📜 <b>سجل طلباتي</b>",
        "fr": "📜 <b>Historique de mes commandes</b>",
    },
    "no_orders":        {
        "en": "📭 You haven't placed any orders yet.",
        "ar": "📭 لم تقم بأي طلبات حتى الآن.",
        "fr": "📭 Vous n'avez encore passé aucune commande.",
    },
    "order_item":       {
        "en": "📦 <b>{name}</b>\n💵 ${amount} • {status} • {date}",
        "ar": "📦 <b>{name}</b>\n💵 ${amount} • {status} • {date}",
        "fr": "📦 <b>{name}</b>\n💵 ${amount} • {status} • {date}",
    },

    # ── PROFILE ───────────────────────────────
    "profile_title":    {
        "en": (
            "👤 <b>My Profile</b>\n\n"
            "🆔 ID: <code>{user_id}</code>\n"
            "👤 Name: <b>{name}</b>\n"
            "📅 Joined: <b>{joined}</b>\n"
            "💰 Balance: <b>${balance}</b>\n"
            "⭐ Stars: <b>{stars}</b>\n"
            "📦 Orders: <b>{orders}</b>\n"
            "🔗 Referrals: <b>{referrals}</b>\n"
            "🌐 Language: <b>{language}</b>"
        ),
        "ar": (
            "👤 <b>ملفي الشخصي</b>\n\n"
            "🆔 المعرف: <code>{user_id}</code>\n"
            "👤 الاسم: <b>{name}</b>\n"
            "📅 تاريخ الانضمام: <b>{joined}</b>\n"
            "💰 الرصيد: <b>${balance}</b>\n"
            "⭐ النجوم: <b>{stars}</b>\n"
            "📦 الطلبات: <b>{orders}</b>\n"
            "🔗 الإحالات: <b>{referrals}</b>\n"
            "🌐 اللغة: <b>{language}</b>"
        ),
        "fr": (
            "👤 <b>Mon Profil</b>\n\n"
            "🆔 ID: <code>{user_id}</code>\n"
            "👤 Nom: <b>{name}</b>\n"
            "📅 Inscrit: <b>{joined}</b>\n"
            "💰 Solde: <b>${balance}</b>\n"
            "⭐ Étoiles: <b>{stars}</b>\n"
            "📦 Commandes: <b>{orders}</b>\n"
            "🔗 Parrainages: <b>{referrals}</b>\n"
            "🌐 Langue: <b>{language}</b>"
        ),
    },

    # ── REFERRAL ──────────────────────────────
    "referral_title":   {
        "en": (
            "🔗 <b>Referral Program</b>\n\n"
            "💵 Earn <b>${bonus}</b> for each friend you invite!\n"
            "🔗 Your referral link:\n{link}\n\n"
            "👥 Total referrals: <b>{count}</b>\n"
            "💰 Total earned: <b>${earned}</b>"
        ),
        "ar": (
            "🔗 <b>برنامج الإحالة</b>\n\n"
            "💵 اكسب <b>${bonus}</b> لكل صديق تدعوه!\n"
            "🔗 رابط الإحالة الخاص بك:\n{link}\n\n"
            "👥 إجمالي الإحالات: <b>{count}</b>\n"
            "💰 إجمالي الأرباح: <b>${earned}</b>"
        ),
        "fr": (
            "🔗 <b>Programme de Parrainage</b>\n\n"
            "💵 Gagnez <b>${bonus}</b> pour chaque ami invité!\n"
            "🔗 Votre lien de parrainage:\n{link}\n\n"
            "👥 Total parrainages: <b>{count}</b>\n"
            "💰 Total gagné: <b>${earned}</b>"
        ),
    },

    # ── SEARCH ────────────────────────────────
    "search_prompt":    {"en": "🔍 Enter search term:", "ar": "🔍 أدخل كلمة البحث:", "fr": "🔍 Entrez le terme de recherche:"},
    "search_results":   {"en": "🔍 Results for: <b>{query}</b>", "ar": "🔍 نتائج لـ: <b>{query}</b>", "fr": "🔍 Résultats pour: <b>{query}</b>"},
    "no_results":       {"en": "🔍 No products found for <b>{query}</b>.", "ar": "🔍 لا توجد منتجات لـ <b>{query}</b>.", "fr": "🔍 Aucun produit trouvé pour <b>{query}</b>."},

    # ── FORCE SUBSCRIBE ───────────────────────
    "subscribe_required": {
        "en": (
            "📌 <b>Subscription Required</b>\n\n"
            "You must join our channel to use this bot.\n"
            "Press the button below to join, then press <b>Check Again</b>."
        ),
        "ar": (
            "📌 <b>الاشتراك مطلوب</b>\n\n"
            "يجب عليك الانضمام إلى قناتنا لاستخدام هذا البوت.\n"
            "اضغط على الزر أدناه للانضمام، ثم اضغط <b>تحقق مجددًا</b>."
        ),
        "fr": (
            "📌 <b>Abonnement Requis</b>\n\n"
            "Vous devez rejoindre notre chaîne pour utiliser ce bot.\n"
            "Appuyez sur le bouton ci-dessous pour rejoindre, puis appuyez sur <b>Vérifier à nouveau</b>."
        ),
    },
    "btn_join_channel": {"en": "📢 Join Channel", "ar": "📢 انضم للقناة", "fr": "📢 Rejoindre la chaîne"},
    "btn_check_again":  {"en": "🔄 Check Again", "ar": "🔄 تحقق مجددًا", "fr": "🔄 Vérifier à nouveau"},
    "not_subscribed":   {
        "en": "❌ You haven't joined the channel yet. Please join and try again.",
        "ar": "❌ لم تنضم إلى القناة بعد. الرجاء الانضمام والمحاولة مجددًا.",
        "fr": "❌ Vous n'avez pas encore rejoint la chaîne. Rejoignez et réessayez.",
    },

    # ── CAPTCHA ───────────────────────────────
    "captcha_question": {
        "en": "🤖 <b>CAPTCHA Verification</b>\n\nWhat is {a} + {b}?",
        "ar": "🤖 <b>التحقق من الهوية</b>\n\nما هو {a} + {b}؟",
        "fr": "🤖 <b>Vérification CAPTCHA</b>\n\nCombien font {a} + {b}?",
    },
    "captcha_wrong":    {"en": "❌ Wrong! Try again.", "ar": "❌ خطأ! حاول مجددًا.", "fr": "❌ Faux! Réessayez."},
    "captcha_passed":   {"en": "✅ Verified! Welcome.", "ar": "✅ تم التحقق! مرحبًا.", "fr": "✅ Vérifié! Bienvenue."},

    # ── LANGUAGE SELECTION ────────────────────
    "select_language":  {
        "en": "🌐 <b>Select Language</b>",
        "ar": "🌐 <b>اختر اللغة</b>",
        "fr": "🌐 <b>Sélectionner la langue</b>",
    },
    "language_changed": {
        "en": "✅ Language changed to <b>English</b>",
        "ar": "✅ تم تغيير اللغة إلى <b>العربية</b>",
        "fr": "✅ Langue changée en <b>Français</b>",
    },

    # ── BOT OFFLINE ───────────────────────────
    "bot_offline":      {
        "en": "🔧 Bot is currently under maintenance. Please try again later.",
        "ar": "🔧 البوت في صيانة حاليًا. يرجى المحاولة لاحقًا.",
        "fr": "🔧 Le bot est actuellement en maintenance. Veuillez réessayer plus tard.",
    },
    "user_banned":      {
        "en": "🚫 You have been banned from using this bot.\nReason: {reason}",
        "ar": "🚫 تم حظرك من استخدام هذا البوت.\nالسبب: {reason}",
        "fr": "🚫 Vous avez été banni de ce bot.\nRaison: {reason}",
    },

    # ── ERRORS ────────────────────────────────
    "error_generic":    {"en": "❌ An error occurred. Please try again.", "ar": "❌ حدث خطأ. يرجى المحاولة مجددًا.", "fr": "❌ Une erreur s'est produite. Veuillez réessayer."},
    "error_not_found":  {"en": "❌ Item not found.", "ar": "❌ العنصر غير موجود.", "fr": "❌ Élément introuvable."},
    "error_cooldown":   {"en": "⏳ Please wait before trying again.", "ar": "⏳ يرجى الانتظار قبل المحاولة مجددًا.", "fr": "⏳ Veuillez attendre avant de réessayer."},

    # ── ADMIN PANEL ───────────────────────────
    "admin_panel":      {
        "en": (
            "👑 <b>Admin Panel</b>\n\n"
            "👥 Users: <b>{users}</b>\n"
            "📦 Orders: <b>{orders}</b>\n"
            "💰 Revenue: <b>${revenue}</b>\n"
            "⏳ Pending Deposits: <b>{deposits}</b>"
        ),
        "ar": (
            "👑 <b>لوحة الإدارة</b>\n\n"
            "👥 المستخدمون: <b>{users}</b>\n"
            "📦 الطلبات: <b>{orders}</b>\n"
            "💰 الإيرادات: <b>${revenue}</b>\n"
            "⏳ الإيداعات المعلقة: <b>{deposits}</b>"
        ),
        "fr": (
            "👑 <b>Panneau Admin</b>\n\n"
            "👥 Utilisateurs: <b>{users}</b>\n"
            "📦 Commandes: <b>{orders}</b>\n"
            "💰 Revenus: <b>${revenue}</b>\n"
            "⏳ Dépôts en attente: <b>{deposits}</b>"
        ),
    },
}

# ─────────────────────────────────────────────
#  TRANSLATION FUNCTION
# ─────────────────────────────────────────────

def _(key: str, lang: str = "en", **kwargs) -> str:
    """
    Translate a key to the given language.
    Falls back to English if language or key not found.
    Supports format kwargs: _("key", lang="ar", name="Ali")
    """
    lang = lang if lang in ("en", "ar", "fr") else "en"
    translations = STRINGS.get(key, {})

    if not translations:
        return f"[{key}]"  # Missing key marker

    text = translations.get(lang) or translations.get("en", f"[{key}]")

    if kwargs:
        try:
            text = text.format(**kwargs)
        except (KeyError, ValueError):
            pass

    return text


def get_language_name(lang_code: str) -> str:
    """Get human-readable language name."""
    names = {
        "en": "🇬🇧 English",
        "ar": "🇸🇦 العربية",
        "fr": "🇫🇷 Français",
    }
    return names.get(lang_code, "🌐 Unknown")


AVAILABLE_LANGUAGES = ["en", "ar", "fr"]
