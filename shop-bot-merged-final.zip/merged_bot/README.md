# 🛒 Premium Telegram Shop Bot v2.0.0

A complete, production-ready Telegram shop bot with automatic digital product delivery, multi-language support, and a full admin panel.

---

## ✨ Features

| Category | Features |
|---|---|
| 🛒 **Shop** | Categories, Products, Pagination, Search |
| 💰 **Payments** | USDT TRC20, Telegram Stars, Balance System |
| 🚀 **Delivery** | Auto file delivery after purchase (all Telegram file types) |
| 👑 **Admin** | Full panel: products, users, deposits, coupons, broadcast |
| 🌐 **Languages** | Arabic, English, French |
| 🔒 **Security** | Force subscribe, Captcha, Ban/Unban, Anti-spam |
| 🎟️ **Marketing** | Coupon system, Referral program |
| 📊 **Analytics** | Stats dashboard, Admin logs, Order history |
| 💾 **Data** | SQLite database, Backup, CSV export |

---

## 📁 Project Structure

```
telegram_shop_bot/
├── bot.py                  # Entry point
├── config.py               # All configuration
├── database.py             # SQLite3 database layer
├── requirements.txt
├── handlers/
│   ├── user_handlers.py    # User flows (shop, balance, orders…)
│   ├── admin_handlers.py   # Admin panel handlers
│   ├── message_handlers.py # Text/file input wizard flows
│   └── callback_router.py  # Central callback dispatcher
├── keyboards/
│   └── inline.py           # All InlineKeyboardMarkup builders
├── languages/
│   └── strings.py          # AR / EN / FR translation strings
└── utils/
    └── helpers.py          # Utilities, decorators, state keys
```

---

## ⚡ Quick Setup

### 1. Install dependencies

```bash
pip install -r requirements.txt
```

> **Pydroid 3 on Android:** Open the pip tab and install `python-telegram-bot==20.7`

### 2. Configure the bot

Edit `config.py`:

```python
BOT_TOKEN = "YOUR_BOT_TOKEN_HERE"        # From @BotFather
ADMIN_IDS = [123456789]                   # Your Telegram user ID
FORCE_SUBSCRIBE_CHANNEL = "yourchannel"  # Without @
FORCE_SUBSCRIBE_CHANNEL_LINK = "https://t.me/yourchannel"
USDT_WALLET = "YOUR_TRC20_WALLET"
SUPPORT_USERNAME = "@your_support"
```

Or use environment variables (recommended for production):

```bash
export BOT_TOKEN="your_token"
export ADMIN_IDS="123456789"
```

### 3. Run the bot

```bash
python bot.py
```

---

## 📱 Pydroid 3 (Android) Setup

1. Install **Pydroid 3** from Play Store
2. Open Pydroid → **Pip** tab → install `python-telegram-bot==20.7`
3. Copy the entire `telegram_shop_bot/` folder to your device
4. Open `config.py`, fill in your token and admin ID
5. Run `bot.py`

---

## 👑 Admin Panel Guide

Send `/start` to your bot. If your user ID is in `ADMIN_IDS`, you'll see the **Admin Panel** button.

### Adding Products

1. Admin Panel → **📦 Products** → **➕ Add Product**
2. Select category → Enter name → price → stars price → stock → description → send file
3. Supported files: zip, apk, txt, pdf, jpg/png, mp4, audio, and any Telegram-supported type

### Managing Deposits (USDT)

1. Admin Panel → **💰 Deposits**
2. Click a pending deposit to see TX hash
3. **✅ Confirm** to credit user balance, **❌ Reject** to decline

### Coupons

- Percentage discount: e.g. 20% off
- Fixed discount: e.g. $5 off
- Set max uses, expiry date, minimum purchase amount

### Settings Toggles

| Toggle | Description |
|---|---|
| 🤖 Bot Status | Enable/disable the bot entirely |
| 🔔 Login Notify | Notify admin when new user joins |
| 📌 Force Subscribe | Require channel subscription |
| 🤖 Captcha | Math captcha on first /start |

---

## 💾 Database Schema

```sql
users          — All bot users with balance and stats
categories     — Product categories
products       — Products with file_id and pricing
orders         — Purchase history
deposits       — USDT deposit requests
coupons        — Discount coupons
coupon_usage   — Which users used which coupons
settings       — Key-value bot settings
admin_logs     — Admin action audit trail
broadcasts     — Broadcast history
referrals      — Referral relationships
support_tickets — User support messages
```

---

## 🔧 Configuration Reference

```python
# config.py

BOT_TOKEN                   = "..."     # BotFather token
ADMIN_IDS                   = [int]     # Admin user IDs
DATABASE_PATH               = "shop.db" # SQLite file path
FORCE_SUBSCRIBE_CHANNEL     = "..."     # Channel username
USDT_WALLET                 = "..."     # TRC20 wallet
MIN_DEPOSIT                 = 1.0       # Minimum USD deposit
STARS_PER_DOLLAR            = 50        # Stars exchange rate
REFERRAL_BONUS              = 0.5       # USD per referral
COOLDOWN_SECONDS            = 1         # Anti-spam cooldown
PRODUCTS_PER_PAGE           = 6         # Products per page
SUPPORT_USERNAME            = "@..."    # Support contact
```

---

## 🛡️ Security Features

- **Rate limiting**: Per-user cooldown + 30 req/min cap
- **Force subscribe**: Users must join channel before using bot
- **Math captcha**: Optional verification on first use
- **Ban system**: Instant ban with reason, banned users see message
- **Bot status**: One-click maintenance mode
- **Admin-only panel**: Verified by Telegram user ID

---

## 📊 Statistics Dashboard

- Total users / new today / new this week
- Total orders / completed orders
- Revenue total / today's revenue
- Active products / categories
- Pending deposits count
- Top 5 best-selling products

---

## 🌐 Multi-Language

Users can switch language anytime via the **🌐 Language** button.

To add a new language:
1. Add entries to `STRINGS` dict in `languages/strings.py`
2. Add the language code to `AVAILABLE_LANGUAGES`
3. Add the flag/name to `get_language_name()`

---

## 📜 License

This project is provided for educational and commercial use. Modify freely.
